let name = prompt("Type your name");
let food = prompt("What's your favorite food?");
let drink = prompt("What`s your favorite drink?");

let obj = {
  name,
  food,
  drink,
};

alert(obj.name + obj.food + obj.drink);
